# example.py - script de demonstração para Readme Light Mode
def main():
    print("Executando demo para: Readme Light Mode")

if __name__ == '__main__':
    main()
