# example.py - script de demonstração para Readme Markdown Examples
def main():
    print("Executando demo para: Readme Markdown Examples")

if __name__ == '__main__':
    main()
