# example.py - script de demonstração para Readme Badges
def main():
    print("Executando demo para: Readme Badges")

if __name__ == '__main__':
    main()
