# example.py - script de demonstração para Readme Sobre Mim
def main():
    print("Executando demo para: Readme Sobre Mim")

if __name__ == '__main__':
    main()
