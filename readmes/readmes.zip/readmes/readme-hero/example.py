# example.py - script de demonstração para Readme Hero
def main():
    print("Executando demo para: Readme Hero")

if __name__ == '__main__':
    main()
