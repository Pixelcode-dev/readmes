# example.py - script de demonstração para Readme Ui Clean
def main():
    print("Executando demo para: Readme Ui Clean")

if __name__ == '__main__':
    main()
