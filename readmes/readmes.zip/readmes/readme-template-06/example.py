# example.py - script de demonstração para Readme Template 06
def main():
    print("Executando demo para: Readme Template 06")

if __name__ == '__main__':
    main()
