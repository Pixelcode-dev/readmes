# example.py - script de demonstração para Readme Design
def main():
    print("Executando demo para: Readme Design")

if __name__ == '__main__':
    main()
