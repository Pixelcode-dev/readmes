# example.py - script de demonstração para Readme Banner
def main():
    print("Executando demo para: Readme Banner")

if __name__ == '__main__':
    main()
