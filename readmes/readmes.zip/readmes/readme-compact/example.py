# example.py - script de demonstração para Readme Compact
def main():
    print("Executando demo para: Readme Compact")

if __name__ == '__main__':
    main()
