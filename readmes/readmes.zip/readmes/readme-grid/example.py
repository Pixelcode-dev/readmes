# example.py - script de demonstração para Readme Grid
def main():
    print("Executando demo para: Readme Grid")

if __name__ == '__main__':
    main()
