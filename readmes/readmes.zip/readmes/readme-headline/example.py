# example.py - script de demonstração para Readme Headline
def main():
    print("Executando demo para: Readme Headline")

if __name__ == '__main__':
    main()
