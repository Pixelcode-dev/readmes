# example.py - script de demonstração para Readme Manga
def main():
    print("Executando demo para: Readme Manga")

if __name__ == '__main__':
    main()
