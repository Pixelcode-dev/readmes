// script.js - comportamento de exemplo para Readme Manga
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Readme Manga'));
});
