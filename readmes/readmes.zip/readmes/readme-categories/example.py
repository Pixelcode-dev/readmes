# example.py - script de demonstração para Readme Categories
def main():
    print("Executando demo para: Readme Categories")

if __name__ == '__main__':
    main()
