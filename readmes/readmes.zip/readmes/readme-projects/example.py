# example.py - script de demonstração para Readme Projects
def main():
    print("Executando demo para: Readme Projects")

if __name__ == '__main__':
    main()
