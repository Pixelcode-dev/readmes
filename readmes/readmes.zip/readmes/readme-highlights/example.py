# example.py - script de demonstração para Readme Highlights
def main():
    print("Executando demo para: Readme Highlights")

if __name__ == '__main__':
    main()
