# example.py - script de demonstração para Readme Dark Glow
def main():
    print("Executando demo para: Readme Dark Glow")

if __name__ == '__main__':
    main()
