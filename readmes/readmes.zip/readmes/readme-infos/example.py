# example.py - script de demonstração para Readme Infos
def main():
    print("Executando demo para: Readme Infos")

if __name__ == '__main__':
    main()
