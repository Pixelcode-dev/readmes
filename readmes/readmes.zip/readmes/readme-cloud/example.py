# example.py - script de demonstração para Readme Cloud
def main():
    print("Executando demo para: Readme Cloud")

if __name__ == '__main__':
    main()
