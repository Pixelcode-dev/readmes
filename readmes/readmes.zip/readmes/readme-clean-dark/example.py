# example.py - script de demonstração para Readme Clean Dark
def main():
    print("Executando demo para: Readme Clean Dark")

if __name__ == '__main__':
    main()
