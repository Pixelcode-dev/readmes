# example.py - script de demonstração para Readme Learning
def main():
    print("Executando demo para: Readme Learning")

if __name__ == '__main__':
    main()
