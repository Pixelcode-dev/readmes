# example.py - script de demonstração para Readme Ai
def main():
    print("Executando demo para: Readme Ai")

if __name__ == '__main__':
    main()
