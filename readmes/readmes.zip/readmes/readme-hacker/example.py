# example.py - script de demonstração para Readme Hacker
def main():
    print("Executando demo para: Readme Hacker")

if __name__ == '__main__':
    main()
