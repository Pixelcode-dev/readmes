# example.py - script de demonstração para Readme Basic Profile
def main():
    print("Executando demo para: Readme Basic Profile")

if __name__ == '__main__':
    main()
