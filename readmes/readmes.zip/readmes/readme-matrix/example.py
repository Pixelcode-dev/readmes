# example.py - script de demonstração para Readme Matrix
def main():
    print("Executando demo para: Readme Matrix")

if __name__ == '__main__':
    main()
