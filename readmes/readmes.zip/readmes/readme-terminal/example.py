# example.py - script de demonstração para Readme Terminal
def main():
    print("Executando demo para: Readme Terminal")

if __name__ == '__main__':
    main()
