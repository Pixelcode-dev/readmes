# example.py - script de demonstração para Readme Template 10
def main():
    print("Executando demo para: Readme Template 10")

if __name__ == '__main__':
    main()
