# example.py - script de demonstração para Readme Professional
def main():
    print("Executando demo para: Readme Professional")

if __name__ == '__main__':
    main()
