# example.py - script de demonstração para Readme Sections
def main():
    print("Executando demo para: Readme Sections")

if __name__ == '__main__':
    main()
