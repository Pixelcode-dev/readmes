# example.py - script de demonstração para Readme Career
def main():
    print("Executando demo para: Readme Career")

if __name__ == '__main__':
    main()
