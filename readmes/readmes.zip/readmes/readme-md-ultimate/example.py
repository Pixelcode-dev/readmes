# example.py - script de demonstração para Readme Md Ultimate
def main():
    print("Executando demo para: Readme Md Ultimate")

if __name__ == '__main__':
    main()
