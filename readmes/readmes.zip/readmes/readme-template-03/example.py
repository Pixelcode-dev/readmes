# example.py - script de demonstração para Readme Template 03
def main():
    print("Executando demo para: Readme Template 03")

if __name__ == '__main__':
    main()
