# example.py - script de demonstração para Readme Social
def main():
    print("Executando demo para: Readme Social")

if __name__ == '__main__':
    main()
