# example.py - script de demonstração para Readme Vision
def main():
    print("Executando demo para: Readme Vision")

if __name__ == '__main__':
    main()
