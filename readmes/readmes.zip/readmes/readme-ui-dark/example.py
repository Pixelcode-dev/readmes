# example.py - script de demonstração para Readme Ui Dark
def main():
    print("Executando demo para: Readme Ui Dark")

if __name__ == '__main__':
    main()
