# example.py - script de demonstração para Readme Roadmap
def main():
    print("Executando demo para: Readme Roadmap")

if __name__ == '__main__':
    main()
