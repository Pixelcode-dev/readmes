# example.py - script de demonstração para Readme Mobile
def main():
    print("Executando demo para: Readme Mobile")

if __name__ == '__main__':
    main()
