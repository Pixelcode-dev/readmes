# example.py - script de demonstração para Readme Git Stats
def main():
    print("Executando demo para: Readme Git Stats")

if __name__ == '__main__':
    main()
