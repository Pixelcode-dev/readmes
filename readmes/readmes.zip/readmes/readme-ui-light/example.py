# example.py - script de demonstração para Readme Ui Light
def main():
    print("Executando demo para: Readme Ui Light")

if __name__ == '__main__':
    main()
