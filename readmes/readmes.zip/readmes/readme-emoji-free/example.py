# example.py - script de demonstração para Readme Emoji Free
def main():
    print("Executando demo para: Readme Emoji Free")

if __name__ == '__main__':
    main()
