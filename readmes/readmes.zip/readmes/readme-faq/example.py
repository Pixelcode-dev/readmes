# example.py - script de demonstração para Readme Faq
def main():
    print("Executando demo para: Readme Faq")

if __name__ == '__main__':
    main()
