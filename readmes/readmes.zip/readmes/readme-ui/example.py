# example.py - script de demonstração para Readme Ui
def main():
    print("Executando demo para: Readme Ui")

if __name__ == '__main__':
    main()
