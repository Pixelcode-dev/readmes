# example.py - script de demonstração para Readme Template 08
def main():
    print("Executando demo para: Readme Template 08")

if __name__ == '__main__':
    main()
