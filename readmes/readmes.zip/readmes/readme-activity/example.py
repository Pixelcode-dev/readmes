# example.py - script de demonstração para Readme Activity
def main():
    print("Executando demo para: Readme Activity")

if __name__ == '__main__':
    main()
