# example.py - script de demonstração para Readme Dark Mode
def main():
    print("Executando demo para: Readme Dark Mode")

if __name__ == '__main__':
    main()
