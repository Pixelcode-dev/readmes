# example.py - script de demonstração para Readme Clean Style
def main():
    print("Executando demo para: Readme Clean Style")

if __name__ == '__main__':
    main()
