# example.py - script de demonstração para Readme Frontend
def main():
    print("Executando demo para: Readme Frontend")

if __name__ == '__main__':
    main()
