# example.py - script de demonstração para Readme Contrib
def main():
    print("Executando demo para: Readme Contrib")

if __name__ == '__main__':
    main()
