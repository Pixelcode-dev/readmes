# example.py - script de demonstração para Readme Fullstack
def main():
    print("Executando demo para: Readme Fullstack")

if __name__ == '__main__':
    main()
