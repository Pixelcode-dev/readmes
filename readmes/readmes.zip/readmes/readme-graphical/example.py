# example.py - script de demonstração para Readme Graphical
def main():
    print("Executando demo para: Readme Graphical")

if __name__ == '__main__':
    main()
