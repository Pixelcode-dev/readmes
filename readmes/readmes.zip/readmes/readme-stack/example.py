# example.py - script de demonstração para Readme Stack
def main():
    print("Executando demo para: Readme Stack")

if __name__ == '__main__':
    main()
