# example.py - script de demonstração para Readme Template 02
def main():
    print("Executando demo para: Readme Template 02")

if __name__ == '__main__':
    main()
