# example.py - script de demonstração para Readme Modern
def main():
    print("Executando demo para: Readme Modern")

if __name__ == '__main__':
    main()
