# example.py - script de demonstração para Readme Extended
def main():
    print("Executando demo para: Readme Extended")

if __name__ == '__main__':
    main()
