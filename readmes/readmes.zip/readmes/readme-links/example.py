# example.py - script de demonstração para Readme Links
def main():
    print("Executando demo para: Readme Links")

if __name__ == '__main__':
    main()
