# example.py - script de demonstração para Readme Minimal
def main():
    print("Executando demo para: Readme Minimal")

if __name__ == '__main__':
    main()
