# example.py - script de demonstração para Readme Stylish
def main():
    print("Executando demo para: Readme Stylish")

if __name__ == '__main__':
    main()
