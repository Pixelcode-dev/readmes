# example.py - script de demonstração para Readme Md Pro
def main():
    print("Executando demo para: Readme Md Pro")

if __name__ == '__main__':
    main()
