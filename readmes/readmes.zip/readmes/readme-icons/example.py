# example.py - script de demonstração para Readme Icons
def main():
    print("Executando demo para: Readme Icons")

if __name__ == '__main__':
    main()
