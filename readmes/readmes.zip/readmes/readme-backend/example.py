# example.py - script de demonstração para Readme Backend
def main():
    print("Executando demo para: Readme Backend")

if __name__ == '__main__':
    main()
