# example.py - script de demonstração para Readme Clean Light
def main():
    print("Executando demo para: Readme Clean Light")

if __name__ == '__main__':
    main()
