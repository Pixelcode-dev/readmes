# example.py - script de demonstração para Readme Progress Bars
def main():
    print("Executando demo para: Readme Progress Bars")

if __name__ == '__main__':
    main()
