# example.py - script de demonstração para Readme Md Min
def main():
    print("Executando demo para: Readme Md Min")

if __name__ == '__main__':
    main()
