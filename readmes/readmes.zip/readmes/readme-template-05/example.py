# example.py - script de demonstração para Readme Template 05
def main():
    print("Executando demo para: Readme Template 05")

if __name__ == '__main__':
    main()
