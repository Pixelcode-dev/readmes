# example.py - script de demonstração para Readme Creative
def main():
    print("Executando demo para: Readme Creative")

if __name__ == '__main__':
    main()
