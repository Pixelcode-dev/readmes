# example.py - script de demonstração para Readme Wiki
def main():
    print("Executando demo para: Readme Wiki")

if __name__ == '__main__':
    main()
