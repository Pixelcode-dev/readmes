# example.py - script de demonstração para Readme Code Blocks
def main():
    print("Executando demo para: Readme Code Blocks")

if __name__ == '__main__':
    main()
