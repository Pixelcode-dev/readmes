# example.py - script de demonstração para Readme Portfolio
def main():
    print("Executando demo para: Readme Portfolio")

if __name__ == '__main__':
    main()
