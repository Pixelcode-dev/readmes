# example.py - script de demonstração para Readme Template 07
def main():
    print("Executando demo para: Readme Template 07")

if __name__ == '__main__':
    main()
