# example.py - script de demonstração para Readme Graph
def main():
    print("Executando demo para: Readme Graph")

if __name__ == '__main__':
    main()
