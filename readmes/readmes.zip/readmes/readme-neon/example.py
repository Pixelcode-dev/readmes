# example.py - script de demonstração para Readme Neon
def main():
    print("Executando demo para: Readme Neon")

if __name__ == '__main__':
    main()
