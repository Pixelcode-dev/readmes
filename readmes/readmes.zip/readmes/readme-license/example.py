# example.py - script de demonstração para Readme License
def main():
    print("Executando demo para: Readme License")

if __name__ == '__main__':
    main()
